package com.onedot.mydoctor;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import de.hdodenhof.circleimageview.CircleImageView;

public class DoctorDetails extends AppCompatActivity {
    public static final String TAG = "DoctorDetails";
    public String ctg;
    public String name;
    public String imageUrl;
    // database
//    private DatabaseReference mDatabase;
//    private Query query;
    public String doctorId;
    //Widget
    CircleImageView profileImage;
    TextView doctorName, doctorCategory;
    ImageView chatSymbol;
    //Firebase
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_details);

        Intent i = getIntent();
        name = i.getStringExtra("doctor_name");
        ctg = i.getStringExtra("doctor_category");
        imageUrl = i.getStringExtra("doctor_image");
        doctorId = i.getStringExtra("doctor_id");

        //Widget init
        profileImage = findViewById(R.id.doctor_details_profile_image);
        doctorName = findViewById(R.id.doctor_details_name);
        doctorCategory = findViewById(R.id.doctor_details_category);
        chatSymbol = findViewById(R.id.doctor_details_message);

//        Picasso.with(getApplicationContext()).load(imageUrl).placeholder(R.drawable.ic_person_black_24dp).into(profileImage);
        Glide.with(getApplicationContext()).load(imageUrl).placeholder(R.drawable.ic_person_black_24dp).into(profileImage);
        doctorName.setText(name);
        doctorCategory.setText(ctg);

        //mProfilePicture imageview init
//        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
//        String uid = currentUser.getUid();

        //Firebase init
        //Firebase Auth init
        mAuth = FirebaseAuth.getInstance();
        // User is signed in
        // User is signed out
//        FirebaseAuth.AuthStateListener mAuthListener = firebaseAuth -> {
//            FirebaseUser user = firebaseAuth.getCurrentUser();
//            if (user != null) {
//                // User is signed in
//                Log.d("TAG", "onAuthStateChanged:signed_in:" + user.getUid());
//            } else {
//                // User is signed out
//                Log.d("TAG", "onAuthStateChanged:signed_out");
//            }
//        };

        //Toolbar initialization
        Toolbar mToolbar = (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Doctor info");

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        chatSymbol.setOnClickListener(view -> {
//            final FirebaseUser currentUser1 = FirebaseAuth.getInstance().getCurrentUser();
            //String uid1 = currentUser1.getUid();

            Intent msgActivity = new Intent(getApplicationContext(), ChatActivity.class);
            msgActivity.putExtra("doctor_name", name);
            msgActivity.putExtra("doctor_id", doctorId);
            startActivity(msgActivity);
            finish();
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_bar_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(DoctorDetails.this, DoctorHome.class));
            finish(); // close this activity and return to preview activity (if there is any)
            return true;
        } else if (item.getItemId() == R.id.main_menu_profile) {
            startActivity(new Intent(DoctorDetails.this, PatientProfile.class));
            finish();
            return true;
        } else if (item.getItemId() == R.id.main_menu_setting) {
            startActivity(new Intent(DoctorDetails.this, PatientProfileSetting.class));
            finish();
            return true;
        } else if (item.getItemId() == R.id.main_menu_logout) {
            mAuth.signOut();
            startActivity(new Intent(DoctorDetails.this, PrimaryLogin.class));
            finish();
            return true;
        }

        return true;
    }
}
