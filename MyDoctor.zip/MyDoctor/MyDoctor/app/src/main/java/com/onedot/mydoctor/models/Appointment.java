package com.onedot.mydoctor.models;

public class Appointment {
    String date, time, doctor, patient, isApproved;
    long timestamp;

    public Appointment() {
    }

    public Appointment(String date, String time, String doctor, String patient, String isApproved, long timestamp) {
        this.date = date;
        this.time = time;
        this.doctor = doctor;
        this.patient = patient;
        this.isApproved = isApproved;
        this.timestamp = timestamp;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDoctor() {
        return doctor;
    }

    public String getPatient() {
        return patient;
    }

    public String getIsApproved() {
        return isApproved;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
