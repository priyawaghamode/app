package com.onedot.mydoctor;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.onedot.mydoctor.PatientDirectory.PatientAppointmentActivity;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class DoctorList extends AppCompatActivity {
    public static final String TAG = "DoctorList";
    public String ctg;
    //Firebase
    private FirebaseAuth mAuth;
    private Query query;
    //RecyclerView
    private RecyclerView mDoctorList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);

        Intent i = getIntent();
        ctg = i.getStringExtra("doctor_category");

        //mProfilePicture imageview init
        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        assert currentUser != null;
        String uid = currentUser.getUid();

        //Retrive from database
        // database
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Doctors");
        query = mDatabase.orderByChild("category").equalTo(ctg);

        //Firebase init
        //Firebase Auth init
        mAuth = FirebaseAuth.getInstance();
        // User is signed in
        // User is signed out
        FirebaseAuth.AuthStateListener mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in
                Log.d("TAG", "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                // User is signed out
                Log.d("TAG", "onAuthStateChanged:signed_out");
            }
        };

        //Toolbar initialization
        Toolbar mToolbar = findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Home");

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        //Recycler view set up for doctor list
        mDoctorList = findViewById(R.id.doctor_list_recycler);
        mDoctorList.setHasFixedSize(true);
        mDoctorList.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Doctors, DoctorsViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Doctors, DoctorsViewHolder>(
                Doctors.class,
                R.layout.sample_doctor_online_list,
                DoctorsViewHolder.class,
                query
        ) {
            @Override
            protected void populateViewHolder(DoctorsViewHolder viewHolder, final Doctors doctor, int position) {
                viewHolder.setName(doctor.getName());
                viewHolder.setCategory(doctor.category);
                viewHolder.setImage(doctor.getImageUrl(), getApplicationContext());
                System.out.println("doctor "  + doctor);
                viewHolder.showOnline(doctor.getOnline());

                viewHolder.itemView.setOnClickListener(view -> {
                    //Intent i = new Intent(DoctorList.this, DoctorDetails.class);
                    Intent i = new Intent(DoctorList.this, PatientAppointmentActivity.class);
                    i.putExtra("doctor_name", doctor.getName());
                    i.putExtra("doctor_category", doctor.getCategory());
                    i.putExtra("doctor_image", doctor.getImageUrl());
                    i.putExtra("doctor_id", doctor.getId());
//                    i.putExtra("doctor_fee", doctor.getfee());
//                    i.putExtra("doctor_exp", doctor.getexp());



                    startActivity(i);
                });
            }
        };
        mDoctorList.setAdapter(firebaseRecyclerAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_bar_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(DoctorList.this, PatientHome.class));
            finish(); // close this activity and return to preview activity (if there is any)
            return true;
        } else if (item.getItemId() == R.id.main_menu_profile) {
            startActivity(new Intent(DoctorList.this, PatientProfile.class));
            finish();
            return true;
        } else if (item.getItemId() == R.id.main_menu_setting) {
            startActivity(new Intent(DoctorList.this, PatientProfileSetting.class));
            finish();
            return true;
        } else if (item.getItemId() == R.id.main_menu_logout) {
            mAuth.signOut();
            startActivity(new Intent(DoctorList.this, PrimaryLogin.class));
            finish();
            return true;
        }

        return true;
    }

    public static class DoctorsViewHolder extends RecyclerView.ViewHolder {
        View mItem;

        public DoctorsViewHolder(View itemView) {
            super(itemView);
            mItem = itemView;
        }

        public void setName(String name) {
            TextView mDoctorName = mItem.findViewById(R.id.doctor_name);
            mDoctorName.setText(name);
        }

        public void setCategory(String ctg) {
            TextView mDoctorName = mItem.findViewById(R.id.doctor_category);
            mDoctorName.setText(ctg);
        }
//        public void setCategory(String ctg) {
//            TextView mDoctorName = mItem.findViewById(R.id.doctor_fee);
//            mDoctorName.setText(fee);
//        }

        public void setImage(String url, Context con) {
            CircleImageView mDoctorImage = mItem.findViewById(R.id.doctor_image);
//            Picasso.with(con).load(url).placeholder(R.drawable.ic_person_black_24dp).into(mDoctorImage);
            Glide.with(con).load(url).placeholder(R.drawable.ic_person_black_24dp).into(mDoctorImage);
        }


        public void showOnline(Boolean b) {
            ImageView onlineImage = mItem.findViewById(R.id.online_image);
            if (b!=null && b) {
                onlineImage.setImageResource(R.drawable.online);
            }
        }
    }
}
