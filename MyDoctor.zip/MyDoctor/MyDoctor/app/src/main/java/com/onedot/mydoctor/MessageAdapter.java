package com.onedot.mydoctor;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {
    private List<Message> mMessageList;
    private FirebaseAuth mAuth;
    private Context context;

    public MessageAdapter(Context context, List<Message> mMessageList) {
        this.context = context;
        this.mMessageList = mMessageList;
    }

    @Override
    public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_single_layout, parent, false);
        return new MessageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MessageViewHolder holder, int position) {
        mAuth = FirebaseAuth.getInstance();
        String current_user = mAuth.getCurrentUser().getUid();

        Message msg = mMessageList.get(position);

        String from_user = msg.getFrom();
        if (from_user.equals(current_user)) {
            holder.mTextMessage.setBackgroundColor(Color.WHITE);
            holder.mTextMessage.setTextColor(Color.BLACK);
        } else {
            holder.mTextMessage.setBackgroundResource(R.drawable.message_text_background);
            holder.mTextMessage.setTextColor(Color.WHITE);
        }

        String msg_type = msg.getType();

        if (msg_type.equals("text")) {
            holder.mTextMessage.setText(msg.getMsg());
            holder.mSendImage.setVisibility(View.INVISIBLE);

        } else {
            holder.mTextMessage.setVisibility(View.INVISIBLE);
            //Picasso.with(context).load(msg.getMsg()).into(holder.mSendImage);
            Glide.with(context).load(msg.getMsg()).into(holder.mSendImage);
        }
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

    class MessageViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextMessage;
        public CircleImageView mProfileImage;
        public ImageView mSendImage;

        public MessageViewHolder(View itemView) {
            super(itemView);

            mTextMessage = itemView.findViewById(R.id.txt_msg);
            mProfileImage = itemView.findViewById(R.id.message_sender_profile_image);
            mSendImage = itemView.findViewById(R.id.msg_image);
        }
    }

}
