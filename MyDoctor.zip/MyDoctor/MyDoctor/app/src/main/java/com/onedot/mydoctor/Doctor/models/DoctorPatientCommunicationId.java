package com.onedot.mydoctor.Doctor.models;


public class DoctorPatientCommunicationId {

    private String doctorId;
    private String patientId;
    private Boolean seen;
    private long timestamp;

    public DoctorPatientCommunicationId(String doctorId, String patientId, Boolean seen, long timestamp) {
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.seen = seen;
        this.timestamp = timestamp;
    }
}
