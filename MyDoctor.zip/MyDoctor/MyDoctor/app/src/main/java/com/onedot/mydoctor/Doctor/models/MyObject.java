package com.onedot.mydoctor.Doctor.models;


public class MyObject {
    public String objectName;

    // constructor for adding sample data
    public MyObject(String objectName) {
        this.objectName = objectName;
    }
}
