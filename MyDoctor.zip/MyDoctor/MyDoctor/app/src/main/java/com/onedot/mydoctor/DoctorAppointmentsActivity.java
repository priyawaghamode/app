package com.onedot.mydoctor;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.onedot.mydoctor.Doctor.activities.DoctorProfile;
import com.onedot.mydoctor.PatientDirectory.PatientAppointmentActivity;
import com.onedot.mydoctor.models.Appointment;

import java.util.Objects;

public class DoctorAppointmentsActivity extends AppCompatActivity {
    RecyclerView rv;
    Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_appointments);

        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        assert currentUser != null;
        String uid = currentUser.getUid();

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Appointments");
        query = mDatabase.orderByChild("isApproved");//.equalTo("false");//orderByChild("timestamp").

        //Toolbar initialization
        Toolbar mToolbar = findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Home");

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        //Recycler view set up for doctor list
        rv = findViewById(R.id.rvAppointment);
        rv.setHasFixedSize(true);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setReverseLayout(true);
        lm.setStackFromEnd(true);
        rv.setLayoutManager(lm);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Appointment, AppointmentViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Appointment, AppointmentViewHolder>(
                        Appointment.class, R.layout.rvitem_appointment, AppointmentViewHolder.class, query) {
                    @Override
                    protected void populateViewHolder(AppointmentViewHolder viewHolder, final Appointment appointment, int position) {
                        viewHolder.setDateTime(appointment.getDate() + " " + appointment.getTime());
                        if(appointment.getPatient()!=null) {
                            System.out.println("appointment.getPatient() " + appointment.getPatient());
                            FirebaseDatabase.getInstance().getReference().child("Users") .child(appointment.getPatient()).child("name").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if(snapshot.getValue()!=null)
                                        viewHolder.setName(snapshot.getValue().toString());
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });
                        }
                        viewHolder.itemView.setOnClickListener(view -> showDialog(appointment.getPatient(), appointment.getTimestamp() + ""));
                    }
                };
        rv.setAdapter(firebaseRecyclerAdapter);
    }

    void showDialog(String id, String timestamp) {
        new AlertDialog.Builder(this).setTitle("Confirmation").setMessage("Do you want to accept this appointment")
                .setPositiveButton("Yes", (dialogInterface, i) -> approveAppointment(id, timestamp) )
                //.setNegativeButton("No", (dialogInterface, i) -> disapproveAppointment(id, timestamp) );
                .setNegativeButton("No", (dialogInterface, i) -> dialogInterface.dismiss()).create().show();
    }


    void approveAppointment(String id, String timestamp) {
        {
            String TAG = "MyActivity";
            Log.i(TAG, "MyClass.getView() — get item number"+id);
            Log.i(TAG, ""+FirebaseDatabase.getInstance().getReference().child("Appointments"));
            FirebaseDatabase.getInstance().getReference().child("Appointments").child(id).removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Approved", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent ( Intent.ACTION_VIEW );
                        intent.setData ( Uri.parse ( "https://wa.me/919075650302/?text=Your Appointment is approved!") );
                        startActivity ( intent );
                      }).addOnFailureListener(e -> {
            });
        }
    }

    void disapproveAppointment(String id, String timestamp) {
        {
            String TAG = "MyActivity";
            Log.i(TAG, "nega"+id);
            FirebaseDatabase.getInstance().getReference().child("Appointments").child(id).removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Approve failed", Toast.LENGTH_SHORT).show();
                        Intent intentt = new Intent ( Intent.ACTION_VIEW );
                        intentt.setData ( Uri.parse ( "https://wa.me/919075650302/?text=Your Appointment is not approved! Please try with different time slot.") );
                        startActivity ( intentt );
                    }).addOnFailureListener(e -> {
            });
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(DoctorAppointmentsActivity.this, DoctorHome.class));
//        finish();

    }

    public static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        View mItem;

        public AppointmentViewHolder(View itemView) {
            super(itemView);
            mItem = itemView;
        }

        public void setDateTime(String name) {
            TextView mDateTime = mItem.findViewById(R.id.tvDateTime);
            mDateTime.setText(name);
        }

        public void setName(String name) {
            TextView mDoctorName = mItem.findViewById(R.id.doctor_name);
            mDoctorName.setText(name);
        }
    }
}