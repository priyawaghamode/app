package com.onedot.mydoctor.Doctor.models;


public class DoctorPatientChatSummary {

    private Boolean seen;
    private long timestamp;

    public DoctorPatientChatSummary(Boolean seen, long timestamp) {
        this.seen = seen;
        this.timestamp = timestamp;
    }

    public Boolean getSeen() {
        return seen;
    }

    public void setSeen(Boolean seen) {
        this.seen = seen;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
