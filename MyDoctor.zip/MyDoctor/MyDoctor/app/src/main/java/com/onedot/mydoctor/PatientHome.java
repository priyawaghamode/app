package com.onedot.mydoctor;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.onedot.mydoctor.PatientDirectory.PatientInbox;
import com.onedot.mydoctor.PatientDirectory.PrescriptionList;

import java.util.ArrayList;
import java.util.Objects;

public class PatientHome extends AppCompatActivity {
    public static final String TAG = "PatientHome";

    //Firebase
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);

        //init RecyclerView
        initRecyclerViewsForPatient();

        //Firebase init
        //Firebase Auth init
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                // User is signed out
                Log.d(TAG, "onAuthStateChanged:signed_out");
            }
        };

        //Toolbar initialization
        Toolbar mToolbar = findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Home");

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void initRecyclerViewsForPatient() {
        RecyclerView recyclerView = findViewById(R.id.patient_home_recycler);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 2);
        recyclerView.setLayoutManager(layoutManager);

        ArrayList<PatientHomeData> list = new ArrayList<>();
//        list.add(new PatientHomeData("Cardiologist", R.drawable.ic_cardi_heart));
        list.add(new PatientHomeData("General Physician", R.drawable.ic_cardi_heart));

//        list.add(new PatientHomeData("Oncologist", R.drawable.ic_oncology));
//        list.add(new PatientHomeData("Pathologist", R.drawable.ic_path_virus));
//        list.add(new PatientHomeData("Hematologist", R.drawable.ic_hematology));
        list.add(new PatientHomeData("Dermatologist", R.drawable.ic_dermatology));

        PatientHomeViewAdapter adapter = new PatientHomeViewAdapter(getApplicationContext(), list);
        recyclerView.setAdapter(adapter);

        //Firebase Auth init
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                // User is signed out
                Log.d(TAG, "onAuthStateChanged:signed_out");
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.patient_menu_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(PatientHome.this, PatientHome.class));
            finish(); // close this activity and return to preview activity (if there is any)
            return true;
        } else if (item.getItemId() == R.id.main_menu_profile) {
            startActivity(new Intent(PatientHome.this, PatientProfile.class));
            finish();
            return true;
        } else if (item.getItemId() == R.id.main_menu_setting) {
            startActivity(new Intent(PatientHome.this, PatientProfileSetting.class));
            finish();
            return true;
//        } else if (item.getItemId() == R.id.main_menu_inbox) {
//            startActivity(new Intent(PatientHome.this, PatientInbox.class));
//            finish();
//            return true;
        } else if (item.getItemId() == R.id.main_menu_logout) {
            mAuth.signOut();
            startActivity(new Intent(PatientHome.this, PrimaryLogin.class));
            finish();
            return true;
        }
//        else if (item.getItemId() == R.id.main_menu_pres) {
//            startActivity(new Intent(PatientHome.this, PrescriptionList.class));
//            finish();
//            return true;


        return true;
    }
}
