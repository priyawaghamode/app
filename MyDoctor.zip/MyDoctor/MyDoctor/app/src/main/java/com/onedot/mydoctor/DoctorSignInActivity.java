package com.onedot.mydoctor;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.onedot.mydoctor.Doctor.activities.DoctorProfile;

public class DoctorSignInActivity extends AppCompatActivity {
    public static final String TAG = "DoctorSignInActivity";
    //EditText
    EditText mEmail, mPassword;
    //Button
    Button mSignIn;
    //Progress dialog
    ProgressDialog signInprogress;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_sign_in);

        //Edittest init
        mEmail = findViewById(R.id.doctor_email_for_sign_in);
        mPassword = findViewById(R.id.doctor_pass_for_sign_in);
        //Button init
        mSignIn = findViewById(R.id.doctor_sign_in_button);
        signInprogress = new ProgressDialog(this);

        doLogin();

        //Sign In Button onClick method
        mSignIn.setOnClickListener(view -> {
            String email = mEmail.getText().toString();
            String password = mPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please fill all requirements", Toast.LENGTH_SHORT).show();
            } else {
                signInprogress.setTitle("Sign In process");
                signInprogress.setMessage("Please wait for a while");
                signInprogress.setCanceledOnTouchOutside(false);
                signInprogress.show();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        signInprogress.dismiss();
//                        startActivity(new Intent(DoctorSignInActivity.this, DoctorHome.class));
//                        finish();
                        doLogin();
                    } else {
                        signInprogress.dismiss();
                        Toast.makeText(getApplicationContext(), "Please enter correct email and password", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    void doLogin() {
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Checking login").setMessage("Please wait").setCancelable(false).create();
        dialog.show();

        //Here we are checking log in session
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
//            Log.d(TAG,"userdata-->"+user.getEmail());
            if (user != null) {
                // User is signed in
                FirebaseDatabase.getInstance().getReference().child("Doctors").child(user.getUid())
                        .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        dialog.dismiss();
                        String s = snapshot.getValue(String.class);
                        //Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
                        if (s != null) {
                            if (s.equals("Doctor")) {
                                startActivity(new Intent(DoctorSignInActivity.this, DoctorHome.class));
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "Wrong credentials provided", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        dialog.dismiss();
                    }
                });
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                dialog.dismiss();
                Toast.makeText(getApplicationContext(), "Wrong credentials provided", Toast.LENGTH_SHORT).show();
            }
        };
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void openDoctorLogin(View view) {
        startActivity(new Intent(DoctorSignInActivity.this, DoctorSignupActivity.class));
    }
}
