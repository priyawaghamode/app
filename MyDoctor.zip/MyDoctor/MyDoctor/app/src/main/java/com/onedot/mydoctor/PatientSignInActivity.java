package com.onedot.mydoctor;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PatientSignInActivity extends AppCompatActivity {
    public static final String TAG = "PatientSignInActivity";
    //EditText
    EditText mEmail, mPassword;
    //Button
    Button mSignIn, mSignUp;
    //Progress dialog
    ProgressDialog signInprogress;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_sign_in);

        //Edittext init
        mEmail = findViewById(R.id.patient_email_for_sign_in);
        mPassword = findViewById(R.id.patient_pass_for_sign_in);
        //Button iinit
        mSignIn = findViewById(R.id.patient_sign_in_button);
        mSignUp = findViewById(R.id.patient_sign_up_button);
        signInprogress = new ProgressDialog(this);

//        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
//        assert currentUser != null;
//        String uid = currentUser.getUid();
//
//        FirebaseDatabase.getInstance().getReference().child("Users").child(uid)
//                .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                String s=snapshot.getValue(String.class);
//                Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) { }
//        });


        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Checking login").setMessage("Please wait").setCancelable(false).create();
        dialog.show();

        //Here we are checking log in session
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in

                FirebaseDatabase.getInstance().getReference().child("Users").child(user.getUid())
                        .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        dialog.dismiss();

                        String s = snapshot.getValue(String.class);
//                        Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
                        if (s != null) {
                            if (s.equals("Patient")) {
                                startActivity(new Intent(PatientSignInActivity.this, PatientHome.class));
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "Wrong credentials provided", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        dialog.dismiss();
                    }
                });
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                dialog.dismiss();
            }
        };

        //Sign In Button onClick method
        mSignIn.setOnClickListener(view -> {
            String email = mEmail.getText().toString();
            String password = mPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please fill all requirements", Toast.LENGTH_SHORT).show();
            } else {
                signInprogress.setTitle("Sign In process");
                signInprogress.setMessage("Please wait for a while");
                signInprogress.setCanceledOnTouchOutside(false);
                signInprogress.show();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        signInprogress.dismiss();
                        startActivity(new Intent(PatientSignInActivity.this, PatientHome.class));
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Please enter correct email and password", Toast.LENGTH_SHORT).show();
                        signInprogress.dismiss();
                    }
                });
            }

        });

        //Sign Up Button onClick method
        mSignUp.setOnClickListener(view -> {
            startActivity(new Intent(PatientSignInActivity.this, PatientSignUp.class));
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(PatientSignInActivity.this, PrimaryLogin.class));
        finish();

    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}
