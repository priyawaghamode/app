package com.onedot.mydoctor.PatientDirectory;


public class MedicineList {
    String name;

    public MedicineList(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
