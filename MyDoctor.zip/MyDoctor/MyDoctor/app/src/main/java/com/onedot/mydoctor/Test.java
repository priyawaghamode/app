package com.onedot.mydoctor;


public class Test {
    private String pid;

    public Test(String pid) {
        this.pid = pid;
    }
}
