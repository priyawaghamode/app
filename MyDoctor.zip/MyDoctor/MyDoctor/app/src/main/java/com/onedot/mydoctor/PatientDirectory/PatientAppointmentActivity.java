package com.onedot.mydoctor.PatientDirectory;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.onedot.mydoctor.DoctorDetails;
import com.onedot.mydoctor.R;
import java.util.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class PatientAppointmentActivity extends AppCompatActivity {
    EditText etDate, etTime;
    Button btnChat;
    String date, time;

    public String ctg, name, imageUrl, doctorId;

    String uid;

    TimePickerDialog timePickerDialog;
    DatePickerDialog datePickerDialog;

    //database
    private DatabaseReference mDatabase;
    //private Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment);

        etDate = findViewById(R.id.etDate);
        etTime = findViewById(R.id.etTime);

        btnChat = findViewById(R.id.btnChat);
        //FirebaseFirestore.getInstance().collection("Appointments").whereEqualTo("appointment_date",your_date).whereEqualTo("speciallist_id",your_speccialist_id)

        Intent i = getIntent();
        name = i.getStringExtra("doctor_name");
        ctg = i.getStringExtra("doctor_category");
        imageUrl = i.getStringExtra("doctor_image");
        doctorId = i.getStringExtra("doctor_id");

        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        assert currentUser != null;
        uid = currentUser.getUid();

        FirebaseDatabase.getInstance().getReference().child("Appointments").child(uid)
                .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String s = snapshot.getValue(String.class);
                //Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
                if (s != null) {
                    if (s.equals("Doctor")) {
                        btnChat.setVisibility(View.VISIBLE);
                    } else {
                        btnChat.setVisibility(View.GONE);
                    }
                } else {
                    btnChat.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        // Get Current Date
        final Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(this,
                (v, year, monthOfYear, dayOfMonth) ->
                        etDate.setText(((dayOfMonth < 10) ? "0" : "") + dayOfMonth + "/" + ((monthOfYear < 10) ? "0" : "") + (monthOfYear + 1) + "/" + year),
                mYear, mMonth, mDay);

        Date newDate = c.getTime();
        datePickerDialog.getDatePicker().setMinDate(newDate.getTime()-(newDate.getTime()%(24*60*60*1000)));

        // Get Current Time
//        final Calendar c = Calendar.getInstance();
        int mHour = c.get(Calendar.HOUR_OF_DAY);
        int mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        timePickerDialog = new TimePickerDialog(this,
                (view1, hourOfDay, minute) -> etTime.setText(((hourOfDay < 10) ? "0" : "") + hourOfDay + ":" + ((minute < 10) ? "0" : "") + minute), mHour, mMinute, false);

        etDate.setOnTouchListener((view, motionEvent) -> {
            if (!datePickerDialog.isShowing()) {
                pickDate(view);
            }
            return false;
        });

        etTime.setOnTouchListener((view, motionEvent) -> {
            if (!timePickerDialog.isShowing()) {
                pickTime(view);
            }
            return false;
        });
    }

    void fixAppointment() {
//        Random rand = new Random();
//// Obtain a number between [0 - 49].
//        int n = rand.nextInt(50000);

        mDatabase = FirebaseDatabase.getInstance().getReference()
                .child("Appointments").child(uid);

        Map userMap = new HashMap();
        userMap.put("date", date);
        userMap.put("time", time);
        userMap.put("doctor", doctorId);
        userMap.put("patient", uid);
        userMap.put("isApproved", "false");
        userMap.put("timestamp", ServerValue.TIMESTAMP);

        mDatabase.setValue(userMap).addOnCompleteListener(task1 -> {
            if (task1.isSuccessful()) {
                Toast.makeText(getApplicationContext(), "Appointment Registered successfully.", Toast.LENGTH_SHORT).show();
                //signUpProgress.dismiss();
//                startActivity(new Intent(PatientAppointmentActivity.this, PatientHome.class));
                finish();
            } else {
                //signUpProgress.dismiss();
                Toast.makeText(getApplicationContext(), "Appointment Registration failed.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void pickTime(View view) {
        timePickerDialog.show();
    }

    public void pickDate(View view) {
        datePickerDialog.show();
    }

    public void fixAppointment(View view) {
        date = etDate.getText().toString().trim();
        time = etTime.getText().toString().trim();

        etDate.setError(null);
        etTime.setError(null);

        if (date.isEmpty()) {
            etDate.setError("Date required");
        } else if (time.isEmpty()) {
            etTime.setError("Time required");
        } else {
            fixAppointment();
        }
    }

    public void openChat(View view) {
        Intent i = new Intent(PatientAppointmentActivity.this, DoctorDetails.class);
        i.putExtra("doctor_name", name);
        i.putExtra("doctor_category", ctg);
        i.putExtra("doctor_image", imageUrl);
        i.putExtra("doctor_id", doctorId);

        startActivity(i);
    }
}