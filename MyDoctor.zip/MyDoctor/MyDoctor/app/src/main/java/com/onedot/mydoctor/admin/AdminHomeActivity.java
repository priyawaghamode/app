package com.onedot.mydoctor.admin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.onedot.mydoctor.DoctorList;
import com.onedot.mydoctor.Doctors;
import com.onedot.mydoctor.R;

import java.util.Objects;

public class AdminHomeActivity extends AppCompatActivity {
    public static final String TAG = "DoctorList";
    public String ctg;
    private Query query;
    //RecyclerView
    private RecyclerView mDoctorList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        Intent i = getIntent();
        ctg = i.getStringExtra("doctor_category");

        //mProfilePicture imageview init
//        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
//        assert currentUser != null;
//        String uid = currentUser.getUid();

        //Retrive from database
        // database
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Doctors");
        query = mDatabase.orderByChild("category");//.equalTo(ctg);

        //Firebase init
        //Firebase Auth init
        //Firebase
//        FirebaseAuth mAuth = FirebaseAuth.getInstance();
//        // User is signed in
//        // User is signed out
//        FirebaseAuth.AuthStateListener mAuthListener = firebaseAuth -> {
//            FirebaseUser user = firebaseAuth.getCurrentUser();
//            if (user != null) {
//                // User is signed in
//                Log.d("TAG", "onAuthStateChanged:signed_in:" + user.getUid());
//            } else {
//                // User is signed out
//                Log.d("TAG", "onAuthStateChanged:signed_out");
//            }
//        };

        //Toolbar initialization
        Toolbar mToolbar = findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Home");

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        //Recycler view set up for doctor list
        mDoctorList = findViewById(R.id.rvAdminhome);
        mDoctorList.setHasFixedSize(true);
        mDoctorList.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Doctors, DoctorList.DoctorsViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Doctors, DoctorList.DoctorsViewHolder>(
                Doctors.class,
                R.layout.sample_doctor_online_list,
                DoctorList.DoctorsViewHolder.class,
                query
        ) {
            @Override
            protected void populateViewHolder(DoctorList.DoctorsViewHolder viewHolder, final Doctors doctor, int position) {
                if(doctor!=null) {
                    viewHolder.setName(doctor.getName());
                    viewHolder.setCategory(doctor.category);
                    viewHolder.setImage(doctor.getImageUrl(), getApplicationContext());
                    viewHolder.showOnline(doctor.getOnline());

                    viewHolder.itemView.setOnClickListener(view -> showDialog(doctor.getId()));
                }
            }
        };
        mDoctorList.setAdapter(firebaseRecyclerAdapter);
    }

    void showDialog(String id) {
        new AlertDialog.Builder(this).setTitle("Confirmation").setMessage("Do you want to delete this doctor")
                .setPositiveButton("Yes", (dialogInterface, i) -> deleteDoctor(id))
                .setNegativeButton("No", (dialogInterface, i) -> dialogInterface.dismiss()).create().show();
    }

    private void deleteDoctor(String id) {
        FirebaseDatabase.getInstance().getReference().child("Doctors").child(id).setValue(null)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Doctor deleted successfully", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Doctor deleted failed", Toast.LENGTH_SHORT).show());
//        FirebaseDatabase.getInstance().getReference().child("Doctors").orderByChild("id").equalTo(id)
//                .addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
//                        for (DataSnapshot postsnapshot :dataSnapshot.getChildren()) {
//                            //String key = postsnapshot.getKey();
//                            dataSnapshot.getRef().removeValue();
//                        }
//                    }
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) { }
//                });
    }
}