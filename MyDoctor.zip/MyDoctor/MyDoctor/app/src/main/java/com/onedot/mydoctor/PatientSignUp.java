package com.onedot.mydoctor;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class PatientSignUp extends AppCompatActivity {
    public static final String TAG = "PatientSignUp";
    //Button
    Button signUp;
    //EditText
    EditText mEmail, mPassword, mConfirmPasswor, mUserName, mAge, mMobile;

    //Progress dialog
    ProgressDialog signUpProgress;
    //ProgressBar
    private ProgressBar mProgressBar;
    //Firebase Auth
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    //Firebase Database
    // Write a message to the database
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_sign_up);

        //Firebase Auth init
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                // User is signed out
                Log.d(TAG, "onAuthStateChanged:signed_out");
            }
        };

        //Button initialization
        signUp = findViewById(R.id.sign_up_button_reg_page);
        //EditText initialization
        mEmail = findViewById(R.id.email_for_sign_up);
        mPassword = findViewById(R.id.pass_for_sign_up);
        mConfirmPasswor = findViewById(R.id.confirm_pass_for_sign_up);
        mUserName = findViewById(R.id.user_name_for__sign_up);
        mAge = findViewById(R.id.Age_for__sign_up);
        mMobile = findViewById(R.id.phone_for__sign_up);

        signUpProgress = new ProgressDialog(this);

        //Sign Up Button onClick method
        signUp.setOnClickListener(view -> {
            String email = mEmail.getText().toString();
            String pass = mPassword.getText().toString();
            String conPass = mConfirmPasswor.getText().toString();
            final String name = mUserName.getText().toString();
            final String Age = mAge.getText().toString();
            final String mobile = mMobile.getText().toString();

            if (!pass.equals(conPass)) {
                Toast.makeText(getApplicationContext(), "Passwords are not same", Toast.LENGTH_SHORT).show();
            } else if (email.isEmpty() || pass.isEmpty() || conPass.isEmpty() || name.isEmpty() || mobile.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please fill all requirements.", Toast.LENGTH_SHORT).show();
            } else {
                signUpProgress.setTitle("Sign Up process");
                signUpProgress.setMessage("Please wait for a while");
                signUpProgress.setCanceledOnTouchOutside(false);
                signUpProgress.show();

                mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                        assert currentUser != null;
                        String uid = currentUser.getUid();

                        //Insert into Database
                        mDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(uid);

                        HashMap<String, String> userMap = new HashMap<>();
                        userMap.put("name", name);
                        userMap.put("mobile", mobile);
                        userMap.put("Age", Age);
                        userMap.put("image", "Default");
                        userMap.put("status", "Patient");

                        mDatabase.setValue(userMap).addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()) {
                                signUpProgress.dismiss();
                                startActivity(new Intent(PatientSignUp.this, PatientHome.class));
                                finish();
                            } else {
                                signUpProgress.dismiss();
                                Toast.makeText(getApplicationContext(), "Registration failed.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        signUpProgress.dismiss();
                        Toast.makeText(getApplicationContext(), "Registration failed.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
