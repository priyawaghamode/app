package com.onedot.mydoctor;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class PatientHomeViewAdapter extends RecyclerView.Adapter<PatientHomeViewAdapter.ViewHolder> {
    public String ctg = null;
    private final ArrayList<PatientHomeData> list;
    private final Context context;

    PatientHomeViewAdapter(Context context, ArrayList<PatientHomeData> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sample_patient_home_single_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.category.setText(list.get(position).getCategory());
        holder.ctgImage.setImageResource(list.get(position).getImageId());

        final String ctg = list.get(position).getCategory();

        holder.itemView.setOnClickListener(view -> {
            Intent i = new Intent(context, DoctorList.class);
            i.putExtra("doctor_category", ctg);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView category;
        private final ImageView ctgImage;

        public ViewHolder(View view) {
            super(view);

            category = view.findViewById(R.id.sample_patient_ctg_txt);
            ctgImage = view.findViewById(R.id.sample_patient_ctg_img);
        }
    }
}
