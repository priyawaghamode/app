package com.onedot.mydoctor.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.onedot.mydoctor.R;

public class AdminLoginActivity extends AppCompatActivity {
    public static final String TAG = "PatientSignInActivity";
    //EditText
    EditText mEmail, mPassword;
    //Button
    Button mSignIn;
    //Progress dialog
    ProgressDialog signInprogress;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        //Edittest init
        mEmail = findViewById(R.id.etMail);
        mPassword = findViewById(R.id.tePasswd);
        //Button iinit
        mSignIn = findViewById(R.id.admin_sign_in_button);
        signInprogress = new ProgressDialog(this);

//        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
//        assert currentUser != null;
//        String uid = currentUser.getUid();

//        FirebaseDatabase.getInstance().getReference().child("Users").child(uid)
//                .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                String s=snapshot.getValue(String.class);
//                Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) { }
//        });

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Checking login").setMessage("Please wait").setCancelable(false).create();
        dialog.show();

        //Here we are checking log in sessio
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {
                // User is signed in
                FirebaseDatabase.getInstance().getReference().child("Admins").child(user.getUid())
                        .child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        dialog.dismiss();
                        String s = snapshot.getValue(String.class);
//                        Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
                        if (s != null) {
                            if (s.equals("Admin")) {
                                startActivity(new Intent(AdminLoginActivity.this, AdminHomeActivity.class));
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "Wrong credentials provided", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        dialog.dismiss();
                    }
                });
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
            } else {
                dialog.dismiss();
            }
        };

        //Sign In Button onClick method
        mSignIn.setOnClickListener(view -> {
            String email = mEmail.getText().toString().trim();
            String password = mPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please fill all requirements", Toast.LENGTH_SHORT).show();
            } else {
                signInprogress.setTitle("Sign In process");
                signInprogress.setMessage("Please wait for a while");
                signInprogress.setCanceledOnTouchOutside(false);
                signInprogress.show();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        signInprogress.dismiss();
                        startActivity(new Intent(AdminLoginActivity.this, AdminHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Please enter correct email and password", Toast.LENGTH_SHORT).show();
                        signInprogress.dismiss();
                    }
                });
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}
