package com.onedot.mydoctor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.onedot.mydoctor.admin.AdminLoginActivity;

public class PrimaryLogin extends AppCompatActivity {
    public static final String TAG = "PatientLogin";
    private SwitchMaterial loginOptionSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primary_login);

        // For switch button
        loginOptionSelect = findViewById(R.id.login_option_selection);
        //For button
        Button getStarted = findViewById(R.id.get_started_button);

        //getStartedButton onClick method
        getStarted.setOnClickListener(view -> {
            if (loginOptionSelect.isChecked()) {
                Intent intent = new Intent(getApplicationContext(), DoctorSignInActivity.class);
                startActivity(intent);
                finish();
            } else {
                Intent intent = new Intent(getApplicationContext(), PatientSignInActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void openAdminLogin(View view) {
        Intent intent = new Intent(getApplicationContext(), AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }
}
